/*
 * Copyright 2010-2022 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */
package kotlin.js

import kotlin.internal.UsedFromCompilerGeneratedCode

@PublishedApi // Used from the JavaScript Plain Objects compiler plugin
@UsedFromCompilerGeneratedCode
internal val VOID: Nothing? = js("void 0")
