/*
 * Copyright 2010-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package kotlin.reflect.jvm.internal.impl.builtins.functions

import kotlin.reflect.jvm.internal.impl.builtins.extractParameterNameFromFunctionTypeArgument
import kotlin.reflect.jvm.internal.impl.descriptors.*
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotations
import kotlin.reflect.jvm.internal.impl.descriptors.impl.FunctionDescriptorImpl
import kotlin.reflect.jvm.internal.impl.descriptors.impl.SimpleFunctionDescriptorImpl
import kotlin.reflect.jvm.internal.impl.descriptors.impl.ValueParameterDescriptorImpl
import kotlin.reflect.jvm.internal.impl.name.Name
import kotlin.reflect.jvm.internal.impl.types.TypeSubstitutor
import kotlin.reflect.jvm.internal.impl.types.Variance
import kotlin.reflect.jvm.internal.impl.util.OperatorNameConventions

class FunctionInvokeDescriptor private constructor(
    container: DeclarationDescriptor,
    original: FunctionInvokeDescriptor?,
    callableKind: CallableMemberDescriptor.Kind,
    isSuspend: Boolean
) : SimpleFunctionDescriptorImpl(
    container,
    original,
    Annotations.EMPTY,
    OperatorNameConventions.INVOKE,
    callableKind,
    SourceElement.NO_SOURCE
) {
    init {
        this.isOperator = true
        this.isSuspend = isSuspend
        this.setHasStableParameterNames(false)
    }

    override fun doSubstitute(configuration: CopyConfiguration): FunctionDescriptor? {
        val substituted = super.doSubstitute(configuration) as FunctionInvokeDescriptor? ?: return null
        if (substituted.valueParameters.none { it.type.extractParameterNameFromFunctionTypeArgument() != null }) return substituted
        val parameterNames = substituted.valueParameters.map { it.type.extractParameterNameFromFunctionTypeArgument() }
        return substituted.replaceParameterNames(parameterNames)
    }

    override fun createSubstitutedCopy(
        newOwner: DeclarationDescriptor,
        original: FunctionDescriptor?,
        kind: CallableMemberDescriptor.Kind,
        newName: Name?,
        annotations: Annotations,
        source: SourceElement
    ): FunctionDescriptorImpl {
        return FunctionInvokeDescriptor(newOwner, original as FunctionInvokeDescriptor?, kind, isSuspend)
    }

    override fun isExternal(): Boolean = false

    override fun isInline(): Boolean = false

    override fun isTailrec(): Boolean = false

    private fun replaceParameterNames(parameterNames: List<Name?>): FunctionDescriptor {
        val indexShift = valueParameters.size - parameterNames.size
        assert(indexShift == 0 || indexShift == 1) // indexShift == 1 for extension function type
        if (indexShift == 0 && parameterNames.zip(valueParameters).all { [name, parameter] -> name == parameter.name }) {
            return this
        }

        val newValueParameters = valueParameters.map {
            var newName = it.name
            val parameterIndex = it.index
            val nameIndex = parameterIndex - indexShift
            if (nameIndex >= 0) {
                val parameterName = parameterNames[nameIndex]
                if (parameterName != null) {
                    newName = parameterName
                }
            }
            it.copy(this, newName, parameterIndex)
        }

        val copyConfiguration = newCopyBuilder(TypeSubstitutor.EMPTY)
            .setHasSynthesizedParameterNames(parameterNames.any { it == null })
            .setValueParameters(newValueParameters)
            .setOriginal(original)

        return super.doSubstitute(copyConfiguration)!!
    }

    companion object Factory {
        fun create(functionClass: FunctionClassDescriptor, isSuspend: Boolean): FunctionInvokeDescriptor {
            val typeParameters = functionClass.declaredTypeParameters

            val result = FunctionInvokeDescriptor(functionClass, null, CallableMemberDescriptor.Kind.DECLARATION, isSuspend)
            result.initialize(
                null,
                functionClass.thisAsReceiverParameter,
                listOf(), listOf(),
                typeParameters.takeWhile { it.variance == Variance.IN_VARIANCE }
                    .withIndex()
                    .map { createValueParameter(result, it.index, it.value) },
                typeParameters.last().defaultType,
                Modality.ABSTRACT,
                DescriptorVisibilities.PUBLIC
            )
            result.setHasSynthesizedParameterNames(true)
            return result
        }

        private fun createValueParameter(
            containingDeclaration: FunctionInvokeDescriptor,
            index: Int,
            typeParameter: TypeParameterDescriptor
        ): ValueParameterDescriptor {
            val name = when (val typeParameterName = typeParameter.name.asString()) {
                "T" -> "instance"
                "E" -> "receiver"
                else -> {
                    // Type parameter "P1" -> value parameter "p1", "P2" -> "p2", etc.
                    typeParameterName.lowercase()
                }
            }

            return ValueParameterDescriptorImpl(
                containingDeclaration, null, index,
                Annotations.EMPTY,
                Name.identifier(name),
                typeParameter.defaultType,
                declaresDefaultValue = false,
                isCrossinline = false,
                isNoinline = false,
                varargElementType = null,
                SourceElement.NO_SOURCE
            )
        }
    }
}
